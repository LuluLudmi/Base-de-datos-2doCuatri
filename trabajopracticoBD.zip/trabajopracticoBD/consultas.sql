SELECT * FROM empleados;

SELECT * FROM libros;

SELECT * FROM editoriales;

DELETE FROM editoriales
WHERE id_editorial = 2;

UPDATE editoriales
SET nombre_editorial = 'La mejor Editorial S.A'
WHERE id_editorial = 8;

DELETE FROM  empleados
WHERE id_empleado = 7;

UPDATE empleados 
SET nombre_empleado = 'Roberto Funes'
WHERE id_empleado = 8;

DELETE FROM libros
WHERE id_libro = 10;

UPDATE libros
SET id_editorial = 3
WHERE id_libro = 5;

DELETE FROM editoriales
WHERE id_editorial = 2;


