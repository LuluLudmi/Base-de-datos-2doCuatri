-- Ejercicio 1:
USE editoriales;
CREATE INDEX idx_libros_id_editorial_titulo ON libros (id_editorial, titulo);
SHOW INDEX
FROM libros;
-- Ejercicio 2:
CREATE INDEX idx_libros_fecha_publicacion ON libros (fecha_publicacion);
-- Ejercicio 3
DROP INDEX idx_libros_id_editorial_titulo ON libros;
SHOW INDEX
FROM libros;
--- Ejercicio 4
CREATE UNIQUE INDEX idx_libros_id_editorial_titulo ON libros(id_editorial);
SHOW INDEX
FROM libros;
-- Ejercicio 5: 
ALTER TABLE libros DROP INDEX idx_libros_id_editorial_titulo;
ALTER TABLE libros
ADD UNIQUE INDEX idx_libros_id_editorial_titulo(id_editorial);
SHOW INDEX
FROM libros;
-- Ejercicio 6: 
CREATE UNIQUE INDEX idx_editoriales_id_editorial ON editoriales(id_editorial);
SHOW INDEX
FROM editoriales;
-- Ejercicio 7
ALTER TABLE libros DROP PRIMARY KEY;
ALTER TABLE libros
ADD PRIMARY KEY (id_libro);
SHOW INDEX
FROM libros;